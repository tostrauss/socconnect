package com.flutterflow.homeU

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
