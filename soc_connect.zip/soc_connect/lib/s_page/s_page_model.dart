import '/flutter_flow/flutter_flow_util.dart';
import 's_page_widget.dart' show SPageWidget;
import 'package:flutter/material.dart';

class SPageModel extends FlutterFlowModel<SPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for input_fullname widget.
  FocusNode? inputFullnameFocusNode;
  TextEditingController? inputFullnameController;
  String? Function(BuildContext, String?)? inputFullnameControllerValidator;
  // State field(s) for input_phonenumber widget.
  FocusNode? inputPhonenumberFocusNode;
  TextEditingController? inputPhonenumberController;
  String? Function(BuildContext, String?)? inputPhonenumberControllerValidator;
  // State field(s) for input_textfield widget.
  FocusNode? inputTextfieldFocusNode;
  TextEditingController? inputTextfieldController;
  String? Function(BuildContext, String?)? inputTextfieldControllerValidator;

  /// Initialization and disposal methods.

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    inputFullnameFocusNode?.dispose();
    inputFullnameController?.dispose();

    inputPhonenumberFocusNode?.dispose();
    inputPhonenumberController?.dispose();

    inputTextfieldFocusNode?.dispose();
    inputTextfieldController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
