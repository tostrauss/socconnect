import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';
import 'mainpage_model.dart';
export 'mainpage_model.dart';

class MainpageWidget extends StatefulWidget {
  const MainpageWidget({super.key});

  @override
  State<MainpageWidget> createState() => _MainpageWidgetState();
}

class _MainpageWidgetState extends State<MainpageWidget> {
  late MainpageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MainpageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AuthUserStreamWidget(
      builder: (context) => StreamBuilder<List<UsersRecord>>(
        stream: queryUsersRecord(
          queryBuilder: (usersRecord) => usersRecord
              .whereNotIn(
                  'uid',
                  functions.combineLists(
                      (currentUserDocument?.matches.toList() ?? []).toList(),
                      (currentUserDocument?.rejected.toList() ?? []).toList()))
              .where(
                'roleEnum',
                isEqualTo: () {
                  if (currentUserDocument?.roleEnum == Role.Coach) {
                    return Role.Player;
                  } else if (currentUserDocument?.roleEnum == Role.Player) {
                    return Role.Coach;
                  } else {
                    return null;
                  }
                }()
                    ?.serialize(),
              ),
          singleRecord: true,
        ),
        builder: (context, snapshot) {
          // Customize what your widget looks like when it's loading.
          if (!snapshot.hasData) {
            return Scaffold(
              backgroundColor: FlutterFlowTheme.of(context).accent3,
              body: Center(
                child: SizedBox(
                  width: 50.0,
                  height: 50.0,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      FlutterFlowTheme.of(context).primary,
                    ),
                  ),
                ),
              ),
            );
          }
          List<UsersRecord> mainpageUsersRecordList =
              snapshot.data!.where((u) => u.uid != currentUserUid).toList();
          final mainpageUsersRecord = mainpageUsersRecordList.isNotEmpty
              ? mainpageUsersRecordList.first
              : null;
          return Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).accent3,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
              automaticallyImplyLeading: false,
              leading: InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  context.pop();
                },
                child: Icon(
                  Icons.chevron_left_rounded,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 32.0,
                ),
              ),
              title: Text(
                'Mainpage',
                style: FlutterFlowTheme.of(context).headlineMedium,
              ),
              actions: const [],
              centerTitle: false,
              elevation: 0.0,
            ),
            body: Container(
              decoration: const BoxDecoration(),
              child: Stack(
                children: [
                  if (mainpageUsersRecord != null)
                    SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FlipCard(
                            fill: Fill.fillBack,
                            direction: FlipDirection.HORIZONTAL,
                            speed: 400,
                            front: Container(),
                            back: Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).tertiary,
                                borderRadius: const BorderRadius.only(
                                  bottomLeft: Radius.circular(12.0),
                                  bottomRight: Radius.circular(12.0),
                                  topLeft: Radius.circular(12.0),
                                  topRight: Radius.circular(12.0),
                                ),
                              ),
                              child: Align(
                                alignment: const AlignmentDirectional(0.0, 0.0),
                                child: Text(
                                  'Back',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Urbanist',
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                      ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                context.pushNamed(
                                  'ProfileInsight',
                                  queryParameters: {
                                    'iDisplay': serializeParam(
                                      mainpageUsersRecord.displayName,
                                      ParamType.String,
                                    ),
                                    'iEmail': serializeParam(
                                      mainpageUsersRecord.email,
                                      ParamType.String,
                                    ),
                                    'iBio': serializeParam(
                                      mainpageUsersRecord.bio,
                                      ParamType.String,
                                    ),
                                    'iRole': serializeParam(
                                      mainpageUsersRecord.positionEnum,
                                      ParamType.Enum,
                                    ),
                                    'iProfilePic': serializeParam(
                                      mainpageUsersRecord.photoUrl,
                                      ParamType.String,
                                    ),
                                    'iActionPics': serializeParam(
                                      mainpageUsersRecord.userPictures,
                                      ParamType.String,
                                      true,
                                    ),
                                  }.withoutNulls,
                                  extra: <String, dynamic>{
                                    kTransitionInfoKey: const TransitionInfo(
                                      hasTransition: true,
                                      transitionType:
                                          PageTransitionType.bottomToTop,
                                    ),
                                  },
                                );
                              },
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12.0),
                                child: Image.network(
                                  mainpageUsersRecord.photoUrl,
                                  width: MediaQuery.sizeOf(context).width * 1.0,
                                  height: 300.0,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Image.asset(
                                    'assets/images/error_image.jpg',
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    height: 300.0,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        context.pushNamed(
                                          'ProfileInsight',
                                          queryParameters: {
                                            'iDisplay': serializeParam(
                                              mainpageUsersRecord.displayName,
                                              ParamType.String,
                                            ),
                                            'iEmail': serializeParam(
                                              mainpageUsersRecord.email,
                                              ParamType.String,
                                            ),
                                            'iBio': serializeParam(
                                              mainpageUsersRecord.bio,
                                              ParamType.String,
                                            ),
                                            'iRole': serializeParam(
                                              mainpageUsersRecord.positionEnum,
                                              ParamType.Enum,
                                            ),
                                            'iProfilePic': serializeParam(
                                              mainpageUsersRecord.photoUrl,
                                              ParamType.String,
                                            ),
                                            'iActionPics': serializeParam(
                                              mainpageUsersRecord.userPictures,
                                              ParamType.String,
                                              true,
                                            ),
                                          }.withoutNulls,
                                          extra: <String, dynamic>{
                                            kTransitionInfoKey: const TransitionInfo(
                                              hasTransition: true,
                                              transitionType: PageTransitionType
                                                  .bottomToTop,
                                            ),
                                          },
                                        );
                                      },
                                      child: Text(
                                        valueOrDefault<String>(
                                          mainpageUsersRecord.displayName,
                                          'name',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .displayLarge
                                            .override(
                                              fontFamily: 'Poppins',
                                              fontSize: 30.0,
                                              fontWeight: FontWeight.normal,
                                            ),
                                      ),
                                    ),
                                    Align(
                                      alignment:
                                          const AlignmentDirectional(1.0, -1.0),
                                      child: Text(
                                        valueOrDefault<String>(
                                          mainpageUsersRecord.age.toString(),
                                          '0',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .headlineMedium
                                            .override(
                                              fontFamily: 'Urbanist',
                                              fontSize: 25.0,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                          0.0, 8.0, 0.0, 8.0),
                                      child: Text(
                                        valueOrDefault<String>(
                                          mainpageUsersRecord.location,
                                          'none',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .titleMedium
                                            .override(
                                              fontFamily: 'Urbanist',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  width: 500.0,
                                  height: 100.0,
                                  decoration: const BoxDecoration(),
                                  child: Text(
                                    valueOrDefault<String>(
                                      mainpageUsersRecord.bio,
                                      'no bio',
                                    ),
                                    style:
                                        FlutterFlowTheme.of(context).labelLarge,
                                  ),
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    FFButtonWidget(
                                      onPressed: () async {
                                        await currentUserReference!.update({
                                          ...mapToFirestore(
                                            {
                                              'rejected': FieldValue.arrayUnion(
                                                  [mainpageUsersRecord.uid]),
                                            },
                                          ),
                                        });

                                        context.pushNamed('Mainpage');
                                      },
                                      text: 'Reject',
                                      options: FFButtonOptions(
                                        width: 150.0,
                                        height: 60.0,
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            24.0, 0.0, 24.0, 0.0),
                                        iconPadding:
                                            const EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color:
                                            FlutterFlowTheme.of(context).error,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              fontFamily: 'Urbanist',
                                              color: Colors.white,
                                            ),
                                        elevation: 3.0,
                                        borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(24.0),
                                      ),
                                    ),
                                    FFButtonWidget(
                                      onPressed: () async {
                                        await currentUserReference!.update({
                                          ...mapToFirestore(
                                            {
                                              'matches': FieldValue.arrayUnion(
                                                  [mainpageUsersRecord.uid]),
                                            },
                                          ),
                                        });
                                        if (mainpageUsersRecord.matches
                                            .contains(currentUserUid)) {
                                          await ChatsRecord.collection
                                              .doc()
                                              .set({
                                            ...createChatsRecordData(
                                              userA: mainpageUsersRecord
                                                  .reference,
                                              userB: currentUserReference,
                                              lastMessage: '\"\"',
                                            ),
                                            ...mapToFirestore(
                                              {
                                                'users': functions
                                                    .createChatsUserList(
                                                        mainpageUsersRecord
                                                            .reference,
                                                        currentUserReference!),
                                                'last_message_time': FieldValue
                                                    .serverTimestamp(),
                                              },
                                            ),
                                          });
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              content: Text(
                                                'Congratulations! You have a new match.',
                                                style: TextStyle(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                ),
                                              ),
                                              duration:
                                                  const Duration(milliseconds: 4000),
                                              backgroundColor:
                                                  FlutterFlowTheme.of(context)
                                                      .secondary,
                                            ),
                                          );
                                          await Future.delayed(const Duration(
                                              milliseconds: 3000));
                                        }

                                        context.pushNamed(
                                          'Mainpage',
                                          extra: <String, dynamic>{
                                            kTransitionInfoKey: const TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                              duration:
                                                  Duration(milliseconds: 0),
                                            ),
                                          },
                                        );
                                      },
                                      text: 'Match',
                                      options: FFButtonOptions(
                                        width: 150.0,
                                        height: 60.0,
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            24.0, 0.0, 24.0, 0.0),
                                        iconPadding:
                                            const EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: FlutterFlowTheme.of(context)
                                            .success,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              fontFamily: 'Urbanist',
                                              color: Colors.white,
                                            ),
                                        elevation: 3.0,
                                        borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(24.0),
                                      ),
                                    ),
                                  ],
                                ),
                              ]
                                  .divide(const SizedBox(height: 12.0))
                                  .around(const SizedBox(height: 12.0)),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
