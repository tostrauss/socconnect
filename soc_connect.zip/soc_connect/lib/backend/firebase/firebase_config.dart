import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyCTA6vJkuaspJ6K2ZogUKnzbZNRKeZD_U0",
            authDomain: "lt-sc-8d0eb.firebaseapp.com",
            projectId: "lt-sc-8d0eb",
            storageBucket: "lt-sc-8d0eb.appspot.com",
            messagingSenderId: "868057041909",
            appId: "1:868057041909:web:6de4fd101bcdbfeb7d2ebc"));
  } else {
    await Firebase.initializeApp();
  }
}
